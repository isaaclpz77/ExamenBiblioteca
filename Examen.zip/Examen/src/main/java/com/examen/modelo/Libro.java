package com.examen.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;
    private int año;

    @ManyToOne
    @JoinColumn(name = "autor_id")
    private Autor autor;

    // Getters y setters
    public Long getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }
    public void setTitulo (String Titulo) {
        this.titulo = titulo;
    }

    public int getAño() {
        return año;
    }
    public void setAnio(int año) {
        this.anio = año;
    }

    public Autor getAutor() {
        return autor;
    }
    public void setAutor (Autor autor) {
        this.autor = autor;
    }
}

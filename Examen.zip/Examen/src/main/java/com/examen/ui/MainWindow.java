package com.examen.ui;

import com.examen.modelo.Autor;
import com.examen.modelo.Libro;

import javax.persistence.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MainWindow extends JFrame {
    private JTextField txtTitulo, txtAnio, txtAutor, txtNacionalidad;
    private JTextArea txtOutput;
    private EntityManagerFactory emf;
    private EntityManager em;

    public MainWindow() {
        super("Examen Biblioteca");
        emf = Persistence.createEntityManagerFactory("bibliotecaPU");
        em = emf.createEntityManager();

        setLayout(new BorderLayout());
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Panel de entrada
        JPanel panelEntrada = new JPanel(new GridLayout(5, 2));
        panelEntrada.setBorder(BorderFactory.createTitledBorder("Registrar Libro"));

        panelEntrada.add(new JLabel("Título del libro:"));
        txtTitulo = new JTextField();
        panelEntrada.add(txtTitulo);

        panelEntrada.add(new JLabel("Año de publicación:"));
        txtAnio = new JTextField();
        panelEntrada.add(txtAnio);

        panelEntrada.add(new JLabel("Nombre del autor:"));
        txtAutor = new JTextField();
        panelEntrada.add(txtAutor);

        panelEntrada.add(new JLabel("Nacionalidad del autor:"));
        txtNacionalidad = new JTextField();
        panelEntrada.add(txtNacionalidad);

        JButton btnGuardar = new JButton("Guardar");
        panelEntrada.add(btnGuardar);

        JButton btnListar = new JButton("Listar Libros");
        panelEntrada.add(btnListar);

        add(panelEntrada, BorderLayout.NORTH);

        // Panel de salida
        JPanel panelSalida = new JPanel();
        panelSalida.setBorder(BorderFactory.createTitledBorder("Libros Registrados"));
        txtOutput = new JTextArea(10, 50);
        txtOutput.setEditable(false);
        panelSalida.add(new JScrollPane(txtOutput));
        add(panelSalida, BorderLayout.CENTER);

        // Acciones
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarLibro();
            }
        });

        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarLibros();
            }
        });
    }

    private void guardarLibro() {
        String titulo = txtTitulo.getText();
        int anio = Integer.parseInt(txtAnio.getText());
        String nombreAutor = txtAutor.getText();
        String nacionalidad = txtNacionalidad.getText();

        em.getTransaction().begin();

        Autor autor = new Autor();
        autor.setNombre(nombreAutor);
        autor.setNacionalidad(nacionalidad);
        em.persist(autor);

        Libro libro = new Libro();
        libro.setTitulo(titulo);
        libro.setAnio(anio);
        libro.setAutor(autor);
        em.persist(libro);

        em.getTransaction().commit();

        JOptionPane.showMessageDialog(this, "Libro guardado correctamente.");
        txtTitulo.setText("");
        txtAnio.setText("");
        txtAutor.setText("");
        txtNacionalidad.setText("");
    }

    private void listarLibros() {
        List<Libro> libros = em.createQuery("SELECT l FROM Libro l", Libro.class).getResultList();
        txtOutput.setText("");
        for (Libro libro : libros) {
            txtOutput.append(libro.getTitulo() + " - " + libro.getAutor().getNombre() + " (" + libro.getAnio() + ")\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainWindow().setVisible(true);
        });
    }
}

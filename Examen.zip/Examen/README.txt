# Examen Biblioteca

## Requisitos
- Java 8+
- Maven
- MySQL (con base de datos y credenciales configuradas en persistence.xml)

## Ejecución

### En Windows
Haz doble clic en `run.bat` o ejecuta desde terminal:
```
run.bat
```

### En Linux/Mac
Dale permisos al script y ejecútalo:
```bash
chmod +x run.sh
./run.sh
```

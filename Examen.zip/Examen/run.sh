#!/bin/bash
echo "Ejecutando Examen Biblioteca..."
mvn clean package
java -cp target/examen-biblioteca-1.0-SNAPSHOT.jar com.examen.ui.MainWindow
